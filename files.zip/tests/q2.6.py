test = {   'name': 'q2.6',
    'points': 5,
    'suites': [{'cases': [{'code': '>>> assoc == True or assoc == False\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
