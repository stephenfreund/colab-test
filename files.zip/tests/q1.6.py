test = {   'name': 'q1.6',
    'points': 5,
    'suites': [   {   'cases': [{'code': '>>> pter_over_time.take(0).column("Date").item(0) == \'1994-01-01\'\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
