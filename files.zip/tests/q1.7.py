test = {   'name': 'q1.7',
    'points': 5,
    'suites': [{'cases': [{'code': '>>> highPTER == True or highPTER == False\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
