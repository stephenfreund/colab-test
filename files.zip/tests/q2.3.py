test = {   'name': 'q2.3',
    'points': 5,
    'suites': [   {   'cases': [{'code': '>>> 5e5 < west_births < 1e6\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> west_births == 979657\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
