test = {   'name': 'q3.5',
    'points': 5,
    'suites': [{'cases': [{'code': '>>> 1 <= boston_median_bin <= 5\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
