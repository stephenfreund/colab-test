test = {   'name': 'q1.4',
    'points': 5,
    'suites': [{'cases': [{'code': '>>> round(pter.item(6), 4) == 1.1282\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
