test = {   'name': 'q1.3',
    'points': 5,
    'suites': [   {   'cases': [   {'code': '>>> greatest_nei.num_rows == 10\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> greatest_nei.take(0).column(0).item(0) == '2009-10-01'\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
