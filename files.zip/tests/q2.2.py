test = {   'name': 'q2.2',
    'points': 5,
    'suites': [{'cases': [{'code': '>>> 0 <= movers.num_rows <= 52\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
