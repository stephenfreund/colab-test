test = {   'name': 'q3.4',
    'points': 5,
    'suites': [   {   'cases': [   {'code': '>>> 0 <= boston_under_15 <= 100\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> 0 <= manila_under_15 <= 100\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
